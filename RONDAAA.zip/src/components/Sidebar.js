import React from "react";
import '../styles/Sidebar.css';
import { FaUserPlus, FaHome, FaRoute, FaBook, FaSignOutAlt } from "react-icons/fa";
import { Link } from "react-router-dom"; // Importe o Link

const Sidebar = ({ isOpen, onLogout }) => {
  const handleLogout = () => {
    localStorage.removeItem("dadosdeUsuario");  
    window.location.href = "/"; 
  };

  return (
    <div className={`sidebar ${isOpen ? "open" : "closed"}`}>
      <ul>
        {/* Usando o Link para navegação */}
        <li>
          <Link to="/user-management">
            <FaUserPlus />
            <span>{isOpen && "Criar Usuário"}</span>
          </Link>
        </li>
        <li>
          <Link to="/create-local">
            <FaHome />
            <span>{isOpen && "Criar Local"}</span>
          </Link>
        </li>
        <li>
          <FaRoute />
          <span>{isOpen && "Criar Rota"}</span>
        </li>
        <li>
          <FaBook />
          <span>{isOpen && "Consultar Registros"}</span>
        </li>
      </ul>
      <button className="logout-button" onClick={handleLogout}>
        <FaSignOutAlt />
        <span>{isOpen && "Sair"}</span>
      </button>
    </div>
  );
};

export default Sidebar;



